/* Desktop wallpapers: Windows 11-style spotlight.
   Right arrow (or the › button, or a leftward swipe) advances to the next picture.
   Left arrow goes back. Arrow keys move desktop icons only while an icon is focused. */
(()=>{
const W=Win12;
const reduce=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
let front=0, shown='', pendingDir=0, timer=0, blob='', vidToken=0, booted=0;

function deck(){
  const ids=(W.walls||[]).map(w=>w[0]).filter(id=>id && id!=='plain');
  return [...new Set(ids)];
}
function srcFor(id){
  if(id==='my'){try{return localStorage.getItem('win12wallpic')}catch{return null}}
  if(id==='spot') return 'images/wallpaper-spotlight.webp';
  if(id==='bloom') return 'images/wallpaper-bloom.webp';
  if(/^w\d\d$/.test(id)) return 'images/wallpapers/'+id+'.svg';
  if(['aurora','sunset','forest'].includes(id)) return 'images/wallpaper-'+id+'.svg';
  return null;
}
function meta(id){
  if(id==='plain') return ['Plain dark','Solid color'];
  if(id==='my'){let n='My picture';try{n=localStorage.getItem('win12wallname')||n}catch{}return [n,'Your photo']}
  if(id==='video') return ['Video','Playing in a loop'];
  const w=(W.walls||[]).find(x=>x[0]===id);
  if(!w) return ['Wallpaper',''];
  if(id==='spot') return [w[1],'Windows Spotlight'];
  return [w[1], w[2]==='Animated'?'Animated wallpaper':'Picture'];
}
function likes(){try{return JSON.parse(localStorage.getItem('win12wallike')||'[]')}catch{return[]}}
function el(html){const t=document.createElement('template');t.innerHTML=html.trim();return t.content.firstChild}

const css=document.createElement('style');
css.textContent=`
#walls{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none;background:#0a1033}
#walls .wl{position:absolute;inset:0;background:#0a1033 center/cover no-repeat;will-change:transform}
#walls video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#000}
#desk,#wg{z-index:1}
#spot{position:fixed;right:14px;bottom:78px;z-index:4;display:flex;align-items:center;gap:4px;max-width:min(420px,calc(100vw - 24px));padding:5px;border-radius:999px;background:#141628d6;backdrop-filter:blur(18px);border:1px solid #ffffff2e;color:#fff;font:13px "Segoe UI",system-ui,sans-serif;box-shadow:0 10px 30px #0006}
#spot button{display:grid;place-items:center;height:44px;min-width:44px;padding:0;border:0;border-radius:999px;background:#ffffff18;color:#fff;cursor:pointer;font:inherit}
#spot button:hover,#spot button:focus-visible{background:#ffffff30;outline:0}
#spot-next{background:#4c6ef5}
#spot-next:hover,#spot-next:focus-visible{background:#3b5bdb}
#spot #spot-info{display:flex;align-items:center;gap:8px;min-width:0;padding:0 12px 0 4px;background:transparent}
#spot-info img{width:36px;height:36px;border-radius:50%;object-fit:cover;background:#0a1033}
#spot-info span{min-width:0;text-align:left}
#spot-info b,#spot-info small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:40vw}
#spot-info b{font-weight:600}
#spot-info small{opacity:.72;font-size:11px}
#spot-like.on{color:#e5484d}
#spot.swap{animation:spotnudge .42s ease}
#spot.swap.prev{animation-name:spotnudgeL}
@keyframes spotnudge{from{transform:translateX(18px)}to{transform:none}}
@keyframes spotnudgeL{from{transform:translateX(-18px)}to{transform:none}}
#wallcap{position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:5;pointer-events:none;padding:8px 16px;border-radius:999px;background:#0c1028d0;color:#fff;font:600 14px "Segoe UI",system-ui,sans-serif;letter-spacing:.01em;opacity:0;transition:opacity .25s ease;box-shadow:0 8px 24px #0006;max-width:46vw;text-align:center}
#wallcap.on{opacity:1}
#spotlive{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
@media (max-width:760px){
  #spot{top:8px;right:8px;bottom:auto}
  #spot-info span{display:none}
  #spot #spot-info{padding:0 2px}
  #spot.swap,#spot.swap.prev{animation:none}
  #wallcap{top:auto;bottom:76px;max-width:70vw}
}
@media (prefers-reduced-motion: reduce){#spot.swap{animation:none}}
`;
document.head.append(css);

const walls=el('<div id="walls"><video muted loop playsinline hidden></video><div class="wl"></div><div class="wl"></div></div>');
const spot=el(`<div id="spot" role="group" aria-label="Wallpaper">
  <button type="button" id="spot-prev" title="Previous wallpaper (Left arrow)" aria-label="Previous wallpaper"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M15 6l-6 6 6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
  <button type="button" id="spot-info" title="This picture"><img alt="" width="36" height="36"><span><b></b><small>→ next picture</small></span></button>
  <button type="button" id="spot-like" title="Like this picture" aria-pressed="false" aria-label="Like this picture"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 20s-7-4.4-7-9a4 4 0 0 1 7-2 4 4 0 0 1 7 2c0 4.6-7 9-7 9z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg></button>
  <button type="button" id="spot-next" title="Next wallpaper (Right arrow)" aria-label="Next wallpaper"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
</div>`);
const live=el('<div id="spotlive" aria-live="polite"></div>');
const cap=el('<div id="wallcap"></div>');
document.body.append(walls, spot, live, cap);
const video=walls.querySelector('video');
const layers=[...walls.querySelectorAll('.wl')];
const info=spot.querySelector('#spot-info'), likeBtn=spot.querySelector('#spot-like');
const nameEl=info.querySelector('b'), subEl=info.querySelector('small'), thumb=info.querySelector('img');

function place(){
  const narrow=matchMedia('(max-width:760px)').matches;
  if(narrow){spot.style.top='8px';spot.style.right='8px';spot.style.bottom='auto';spot.style.left='auto';return}
  spot.style.top='auto';spot.style.left='auto';spot.style.right='14px';
  const bar=document.getElementById('bar');
  spot.style.bottom=bar?(Math.round(innerHeight-bar.getBoundingClientRect().top)+12)+'px':'78px';
}
function applyBg(node,id,src){
  node.style.backgroundColor=id==='plain'?'#0a1033':'#061028';
  node.style.backgroundImage=src?'url("'+String(src).replace(/"/g,'')+'")':'none';
}
function paint(id, dir){
  if(id==='video'){
    layers.forEach(n=>{n.style.opacity='0'});
    video.hidden=false;
    const token=++vidToken;
    W.idb.get('wallvideo').then(f=>{
      if(token!==vidToken||!f) return;
      const u=URL.createObjectURL(f);
      if(blob) URL.revokeObjectURL(blob);
      blob=u; video.src=u; video.play().catch(()=>{});
    }).catch(()=>{});
    return;
  }
  ++vidToken; video.pause(); video.hidden=true;
  const src=srcFor(id), a=layers[front], b=layers[1-front];
  if(reduce()||!shown){
    layers.forEach(n=>{n.style.transition='none';n.style.opacity='1'});
    applyBg(a,id,src); a.style.transform='translate3d(0,0,0)'; b.style.transform='translate3d(100%,0,0)';
    return;
  }
  if(!dir){
    b.style.transition='none'; b.style.transform='translate3d(0,0,0)'; b.style.opacity='0'; applyBg(b,id,src);
    b.offsetWidth;
    a.style.transition=b.style.transition='opacity .4s ease';
    a.style.opacity='0'; b.style.opacity='1';
    front=1-front; return;
  }
  b.style.transition='none'; a.style.opacity=b.style.opacity='1';
  applyBg(b,id,src);
  b.style.transform='translate3d('+(dir*100)+'%,0,0)';
  b.offsetWidth;
  const t='transform .55s cubic-bezier(.22,.8,.24,1)';
  a.style.transition=b.style.transition=t;
  a.style.transform='translate3d('+(-dir*100)+'%,0,0)';
  b.style.transform='translate3d(0,0,0)';
  front=1-front;
}
function renderChip(id, dir){
  const [name, kind]=meta(id);
  nameEl.textContent=name;
  subEl.textContent=kind?kind+' · →':'→ next picture';
  const src=srcFor(id);
  if(src){thumb.hidden=false; thumb.src=src; thumb.alt=''} else thumb.hidden=true;
  const on=likes().includes(id);
  likeBtn.classList.toggle('on', on);
  likeBtn.setAttribute('aria-pressed', on?'true':'false');
  likeBtn.querySelector('path').setAttribute('fill', on?'currentColor':'none');
  if(dir){spot.classList.toggle('prev', dir<0); spot.classList.remove('swap'); spot.offsetWidth; spot.classList.add('swap')}
  if(shown && shown!==id) live.textContent='Wallpaper: '+name;
}
function arm(s){
  clearInterval(timer); timer=0;
  const sec=+s.slide||0;
  if(sec>0) timer=setInterval(()=>{if(!document.hidden) advance(1,true)}, sec*1000);
}
function sync(s){
  s=s||W.settings();
  const id=s.wallpaper||'bloom';
  const dir=pendingDir; pendingDir=0;
  place(); arm(s); renderChip(id, dir);
  if(id===shown && !dir) return;
  paint(id, shown?dir:0);
  shown=id;
}
function advance(dir, silent){
  const list=deck(); if(!list.length) return;
  const cur=(W.settings().wallpaper)||'bloom';
  let i=list.indexOf(cur);
  i=i<0?(dir>0?0:list.length-1):(i+dir+list.length)%list.length;
  pendingDir=dir;
  if(!silent){
    const [name]=meta(list[i]);
    cap.textContent=name;
    cap.classList.add('on');
    clearTimeout(cap._t); cap._t=setTimeout(()=>cap.classList.remove('on'),1400);
  }
  W.set({wallpaper:list[i]});
}
function moveIcon(from, key){
  const icons=[...document.querySelectorAll('#desk .ic')];
  const r=from.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2;
  const pref={ArrowRight:[1,0],ArrowLeft:[-1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[key];
  if(!pref) return;
  let best=null, score=1e9;
  for(const ic of icons){
    if(ic===from) continue;
    const b=ic.getBoundingClientRect();
    const dx=b.left+b.width/2-cx, dy=b.top+b.height/2-cy;
    const along=dx*pref[0]+dy*pref[1];
    if(along<18) continue;
    const cross=Math.abs(dx*pref[1]-dy*pref[0]);
    const s=cross*8+along;
    if(s<score){score=s; best=ic}
  }
  if(!best) return;
  document.querySelectorAll('#desk .ic.sel').forEach(n=>n.classList.remove('sel'));
  best.classList.add('sel'); best.focus({preventScroll:true});
}
function targetEl(e){const t=e.target; return t && t.nodeType===1 ? t : document.body}

spot.querySelector('#spot-next').onclick=()=>advance(1);
spot.querySelector('#spot-prev').onclick=()=>advance(-1);
likeBtn.onclick=()=>{
  const id=W.settings().wallpaper||'bloom';
  let a=likes(); a=a.includes(id)?a.filter(x=>x!==id):a.concat(id);
  try{localStorage.setItem('win12wallike', JSON.stringify(a))}catch{}
  renderChip(id, 0);
};
info.onclick=()=>{const id=W.settings().wallpaper||'bloom'; const [name,kind]=meta(id); if(typeof note==='function') note(name+(kind?' — '+kind:'')+'. Right arrow for the next wallpaper.')};

addEventListener('keydown',e=>{
  if(e.altKey||e.ctrlKey||e.metaKey) return;
  const t=targetEl(e);
  const sleep=document.getElementById('sleep');
  if(sleep && sleep.classList.contains('on')) return;
  const icon=t.closest && t.closest('#desk .ic');
  if(icon && (e.key==='ArrowRight'||e.key==='ArrowLeft'||e.key==='ArrowUp'||e.key==='ArrowDown')){e.preventDefault(); if(!e.repeat) moveIcon(icon, e.key); return}
  if(icon && e.key==='Enter'){e.preventDefault(); if(icon._go) icon._go(); return}
  if(e.key!=='ArrowRight' && e.key!=='ArrowLeft') return;
  if(e.shiftKey||e.repeat) return;
  if(t.closest && t.closest('input,textarea,select,[contenteditable="true"]')) return;
  for(const id of ['run','menu','news','qs']){const n=document.getElementById(id); if(n && n.classList.contains('on')) return}
  const ctx=document.getElementById('ctx'); if(ctx && ctx.style.display==='block') return;
  if(t.closest && t.closest('button,a') && !(t.closest('#spot'))) return;
  e.preventDefault();
  advance(e.key==='ArrowRight'?1:-1);
}, true);

const desk=document.getElementById('desk');
if(desk){
  desk.tabIndex=-1;
  desk.addEventListener('pointerdown',e=>{
    if(e.target!==desk) return;
    document.querySelectorAll('#desk .ic.sel').forEach(n=>n.classList.remove('sel'));
    desk.focus({preventScroll:true});
  });
  let sx=0, sy=0, drag=0;
  desk.addEventListener('pointerdown',e=>{if(e.target!==desk) return; drag=1; sx=e.clientX; sy=e.clientY});
  addEventListener('pointerup',e=>{
    if(!drag) return; drag=0;
    const dx=e.clientX-sx, dy=e.clientY-sy;
    if(Math.abs(dx)<70 || Math.abs(dx)<Math.abs(dy)*1.3) return;
    advance(dx<0?1:-1);
  });
  desk.addEventListener('click',e=>{
    const b=e.target.closest && e.target.closest('.ic');
    if(b && (W.settings().click||'single')==='single') b.blur();
  });
}
addEventListener('resize', place);

const prev=W.apply;
W.apply=function(s){prev.call(W,s); try{sync(s)}catch(err){console.error(err)}};
W.load().then(()=>{
  if(booted) return; booted=1; sync();
  try{if(!sessionStorage.getItem('win12wallhint') && typeof note==='function'){sessionStorage.setItem('win12wallhint','1'); setTimeout(()=>note('Press the Right arrow key for the next wallpaper.'), 700)}}catch{}
});
window.Wall={next:()=>advance(1), prev:()=>advance(-1), advance, peek(dir){pendingDir=dir||0}};
place();
})();
