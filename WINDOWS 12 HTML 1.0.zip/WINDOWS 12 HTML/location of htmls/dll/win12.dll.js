/* Win12 shared library ("dll"): loads Professional.xml, keeps settings, applies them to the desktop.
   Professional.xml is also embedded below, because file:// pages cannot fetch local files. */
const Win12=(()=>{
const BASE=document.currentScript.src.replace(/dll\/[^/]*$/,''),INLINE="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!-- Windows 12 Professional: edition, folders, defaults, apps and extensions -->\n<Windows12 edition=\"Professional\">\n  <Edition>\n    <Name>Windows 12 Professional</Name>\n    <Version>1.0</Version>\n    <Build>26000.1</Build>\n    <Publisher>PhoneLink Systems</Publisher>\n  </Edition>\n  <Paths>\n    <Folder name=\"Install\">C:\\phonelink\\WINDOWS 12 HTML</Folder>\n    <Folder name=\"BIOS\">C:\\phonelink\\WINDOWS 12 HTML\\bios</Folder>\n    <Folder name=\"Apps\">C:\\phonelink\\WINDOWS 12 HTML\\location\\Windows\\winApp</Folder>\n    <Folder name=\"Htmls\">C:\\phonelink\\WINDOWS 12 HTML\\location of htmls</Folder>\n    <Folder name=\"DLL\">C:\\phonelink\\WINDOWS 12 HTML\\location of htmls\\dll</Folder>\n    <Folder name=\"Extensions\">C:\\phonelink\\WINDOWS 12 HTML\\location of htmls\\exten</Folder>\n    <Folder name=\"Admin\">C:\\phonelink\\WINDOWS 12 HTML\\admin</Folder>\n    <Folder name=\"AppManager\">C:\\phonelink\\WINDOWS 12 HTML\\admin\\Appmanger</Folder>\n    <Folder name=\"DiskManager\">C:\\phonelink\\WINDOWS 12 HTML\\admin\\diskmanger</Folder>\n    <Folder name=\"Documents\">C:\\phonelink\\WINDOWS 12 HTML\\admin\\Documents</Folder>\n    <Folder name=\"Installer\">C:\\phonelink\\WINDOWS 12 HTML\\installer</Folder>\n    <Folder name=\"Cleaner\">C:\\phonelink\\WINDOWS 12 HTML\\admin\\Cleaner</Folder>\n    <Folder name=\"AppData (hidden)\">C:\\phonelink\\WINDOWS 12 HTML\\admin\\AppData</Folder>\n    <Folder name=\"Downloads\">C:\\phonelink\\WINDOWS 12 HTML\\admin\\Downloads</Folder>\n    <Folder name=\"Desktop\">C:\\phonelink\\WINDOWS 12 HTML\\admin\\Desktop</Folder>\n  </Paths>\n  <Defaults>\n    <Accent>#4c6ef5</Accent>\n    <Taskbar>round</Taskbar>\n    <Wallpaper>bloom</Wallpaper>\n  </Defaults>\n  <Apps>\n    <App file=\"location/Windows/winApp/explorer.html\" icon=\"location/Windows/winApp/icons/explorer.svg\">File Explorer</App>\n    <App file=\"location/Windows/winApp/chrome.html\" icon=\"location/Windows/winApp/icons/chrome.svg\">Google Chrome</App>\n    <App file=\"location/Windows/winApp/youtube.html\" icon=\"location/Windows/winApp/icons/youtube.svg\">YouTube</App>\n    <App file=\"location/Windows/winApp/cmd.html\" icon=\"location/Windows/winApp/icons/cmd.svg\">Command Prompt</App>\n    <App file=\"location/Windows/winApp/screenshare.html\" icon=\"location/Windows/winApp/icons/screenshare.svg\">Screen Share</App>\n    <App file=\"location of htmls/settings.html\" icon=\"location/Windows/winApp/icons/settings.svg\">Settings</App>\n    <App file=\"location of htmls/exten/extension.html\" icon=\"location/Windows/winApp/icons/extension.svg\">Extensions</App>\n    <App file=\"location/Windows/winApp/texteditor.html\" icon=\"location/Windows/winApp/icons/texteditor.svg\">Text Editor</App>\n    <App file=\"location/Windows/winApp/notepad.html\" icon=\"location/Windows/winApp/icons/notepad.svg\">Notepad</App>\n    <App file=\"location/Windows/winApp/calculator.html\" icon=\"location/Windows/winApp/icons/calculator.svg\">Calculator</App>\n    <App file=\"location/Windows/winApp/help.html\" icon=\"location/Windows/winApp/icons/help.svg\">Help</App>\n    <App file=\"admin/Appmanger/appmanger.html\" icon=\"location/Windows/winApp/icons/appmanager.svg\">App Manager</App>\n    <App file=\"admin/diskmanger/diskmanger.html\" icon=\"location/Windows/winApp/icons/diskmanager.svg\">Disk Manager</App>\n    <App file=\"admin/Cleaner/cleaner.html\" icon=\"location/Windows/winApp/icons/cleaner.svg\">Storage Cleaner</App>\n    <App file=\"location/Windows/winApp/taskmanager.html\" icon=\"location/Windows/winApp/icons/taskmanager.svg\">Task Manager</App>\n    <App file=\"location/Windows/winApp/ai.html\" icon=\"location/Windows/winApp/icons/ai.svg\">AI Assistant</App>\n    <App file=\"bios/bios.html\" icon=\"location/Windows/winApp/icons/bios.svg\">BIOS</App>\n    <App file=\"bios/setup.html\" icon=\"location/Windows/winApp/icons/setup.svg\">BIOS Setup</App>\n  </Apps>\n  <Extensions>\n    <Extension id=\"widgets\" name=\"Desktop widgets\" enabled=\"true\">Clock, calendar and system widgets on the desktop.</Extension>\n    <Extension id=\"news\" name=\"Bing News\" enabled=\"true\">News button on the taskbar that searches Bing News.</Extension>\n    <Extension id=\"remote\" name=\"Remote Desktop host\" edition=\"Professional\" enabled=\"false\">Lets another PC connect to this one. Demo only, no effect yet.</Extension>\n    <Extension id=\"encrypt\" name=\"Drive encryption\" edition=\"Professional\" enabled=\"true\">Encrypts drives using the TPM. Demo only, no effect yet.</Extension>\n    <Extension id=\"vm\" name=\"Virtual machines\" edition=\"Professional\" enabled=\"true\">Runs virtual PCs and needs CPU Virtualization in BIOS. Demo only, no effect yet.</Extension>\n  </Extensions>\n</Windows12>\n",KEY='win12settings';
let doc;
const W={
 async load(){let t=INLINE;try{const r=await fetch(BASE+'Professional.xml');if(r.ok)t=await r.text()}catch{}
  doc=new DOMParser().parseFromString(t,'application/xml');return W},
 text:p=>doc?((doc.querySelector(p)||{}).textContent||'').trim():'',
 all:p=>doc?[...doc.querySelectorAll(p)]:[],
 settings(){let o={};try{o=JSON.parse(localStorage.getItem(KEY)||'{}')}catch{}
  const ext={};W.all('Extension').forEach(e=>ext[e.getAttribute('id')]=e.getAttribute('enabled')!='false');
  return{accent:W.text('Defaults > Accent'),taskbar:W.text('Defaults > Taskbar'),wallpaper:W.text('Defaults > Wallpaper'),...o,ext:{...ext,...o.ext}}},
 save(s){try{localStorage.setItem(KEY,JSON.stringify(s))}catch{}},
 apply(s=W.settings()){
  const css=`:root{--ac:${s.accent}}
.cal .today,#nq button{background:${s.accent}!important}
${s.taskbar=='full'?'#bar{left:0!important;right:0!important;bottom:0!important;border-radius:0!important}':''}
${s.wallpaper=='plain'?'body{background-image:none!important}':(document.getElementById('desk')?(/^w\d\d$/.test(s.wallpaper)?'body{background-image:url(images/wallpapers/'+s.wallpaper+'.svg)!important}':['aurora','sunset','forest'].includes(s.wallpaper)?'body{background-image:url(images/wallpaper-'+s.wallpaper+'.svg)!important}':''):'')}
${s.align=='left'?'#bar{justify-content:flex-start!important;padding-left:64px}':''}
${s.size=='small'?'#bar{height:46px!important}#bar .ic{width:36px;height:36px}#bar .ic img{width:22px;height:22px}':s.size=='large'?'#bar{height:64px!important;border-radius:32px!important}#bar .ic{width:52px;height:52px}#bar .ic img{width:32px;height:32px}':''}
${s.search=='hidden'?'#sbx{display:none!important}':s.search=='icon'?'#bar #sbx{width:44px;padding:0;border-radius:50%}#bar #sbx span{display:none}':''}
${s.tbh?'#bar{height:'+s.tbh+'px!important;border-radius:'+s.tbh/2+'px!important}#bar .ic{width:'+(s.tbh-10)+'px!important;height:'+(s.tbh-10)+'px!important}#bar #sbx{width:auto!important}#bar .ic img{width:'+(s.tbh-28)+'px;height:'+(s.tbh-28)+'px}':''}
${s.ext.widgets===false?'#wg{display:none!important}':''}
${s.ext.news===false?'#nw{display:none!important}':''}`;
  let t=document.getElementById('w12css');if(!t){t=document.createElement('style');t.id='w12css';document.head.append(t)}t.textContent=css+W.styler(s)},
 renderExtensions(el,done){const s=W.settings();
  el.innerHTML=W.all('Extension').map(e=>{const id=e.getAttribute('id');
   return`<label class="ext"><span><b>${e.getAttribute('name')}</b> ${e.getAttribute('edition')=='Professional'?'<em>Professional</em>':''}<small>${e.textContent.trim()}</small></span><input type="checkbox" data-id="${id}"${s.ext[id]?' checked':''}></label>`}).join('');
  el.onchange=ev=>{const s2=W.settings();s2.ext[ev.target.dataset.id]=ev.target.checked;W.save(s2);W.apply(s2);if(done)done(s2)}},
 appsCfg(){let o={};try{o=JSON.parse(localStorage.getItem('win12apps')||'{}')}catch{}return{off:[],start:[],size:'Medium',single:false,confirm:false,pins:['File Explorer','Google Chrome','YouTube','Command Prompt'],...o}},
 setAppsCfg(o){try{localStorage.setItem('win12apps',JSON.stringify({...W.appsCfg(),...o}))}catch{}},
 findApp(t){t=t.toLowerCase().replace(/\.(exe|html)$/,'').replace(/\s+/g,'');const al={calc:'calculator',explorer:'fileexplorer',chrome:'googlechrome',cmd:'commandprompt',yt:'youtube',msconfig:'appmanager',diskmgmt:'diskmanager',control:'settings',share:'screenshare',cast:'screenshare'};t=al[t]||t;
  const e=W.all('App').find(e=>e.textContent.trim().toLowerCase().replace(/\s/g,'')==t);return e?e.textContent.trim():null},
 async runFile(n){const f=W.fs.files(),k=Object.keys(f).find(x=>x.toLowerCase()==n.toLowerCase());if(!k)return null;
  if(/\.clp$/i.test(k)){try{await navigator.clipboard.writeText(f[k]);return{msg:'Copied '+f[k].length+' characters from '+k+' to the clipboard.'}}catch{return{msg:'The browser blocked clipboard access.'}}}
  if(/\.lpc$/i.test(k))return{app:'Screen Share',msg:'Opening Screen Share with '+k};return null},
 tree:(()=>{const R='WINDOWS 12 HTML',ic=(n,o)=>Object.fromEntries(n.split(' ').map(k=>[k,o||0])),X='ico png apk exe pdf lnk txt zip html js md log tmp'.split(' ');
  return{[R]:{
   bios:ic('bios.html bios.txt setup.html settings.js'),
   images:{icons:ic('access.svg cast.svg news.svg restart.svg search.svg shutdown.svg sleep.svg'),wallpapers:ic('w01.svg w02.svg w03.svg w04.svg w05.svg w06.svg w07.svg w08.svg w09.svg w10.svg w11.svg w12.svg w13.svg w14.svg w15.svg w16.svg w17.svg w18.svg w19.svg w20.svg w21.svg w22.svg w23.svg w24.svg w25.svg w26.svg w27.svg w28.svg w29.svg w30.svg w31.svg'),...ic('logo.svg logo.png logo.ico wallpaper.svg wallpaper-aurora.svg wallpaper-sunset.svg wallpaper-forest.svg')},
   installer:ic('installer.html installer.css installer.js'),
   location:{Windows:{winApp:{icons:ic('ai.svg appmanager.svg bios.svg calculator.svg chrome.svg cleaner.svg cmd.svg diskmanager.svg explorer.svg extension.svg help.svg notepad.svg screenshare.svg settings.svg setup.svg taskmanager.svg texteditor.svg youtube.svg'),...ic('ai.html calculator.html chrome.html cmd.html explorer.html help.html notepad.html screenshare.html taskmanager.html texteditor.html youtube.html')},Intel:ic('IntelCPHS.log IntelGFX.log IntelGFXCoin.log'),Temp:ic('WRPC052.tmp'),ESD:ic('readme.txt'),inetpub:ic('readme.txt'),Games:ic('readme.txt'),...ic('info.txt')}},
   'location of htmls':{dll:ic('dll.svg install.dll.js tray.css utilman.dll.js win12.dll.js'),exten:ic('extension.html'),mobile:ic('viewer.html'),...Object.fromEntries(X.map(e=>[e,ic(e+'.svg')])),...ic('Professional.xml settings.html')},
   admin:{Appmanger:ic('appmanger.html'),Cleaner:ic('cleaner.html'),diskmanger:ic('diskmanger.html')},
   ...ic('index.html loading.js start.html')}}})(),
 set(o){const s={...W.settings(),...o};W.save(s);W.apply(s)},
 walls:[["bloom", "Bloom", "Image"], ["aurora", "Aurora", "Image"], ["sunset", "Sunset", "Image"], ["forest", "Forest", "Image"], ["w01", "Dawn Peaks", "Image"], ["w02", "Dusk Ridge", "Image"], ["w03", "Misty Pines", "Image"], ["w04", "Midnight City", "Image"], ["w05", "Violet Skyline", "Image"], ["w06", "Pastel Blobs", "Image"], ["w07", "Ember Glow", "Image"], ["w08", "Calm Ocean", "Image"], ["w09", "Teal Tide", "Image"], ["w10", "Golden Dunes", "Image"], ["w11", "Triangles", "Image"], ["w12", "Polka Dots", "Image"], ["w13", "Stripes", "Image"], ["w14", "Retro Sun", "Image"], ["w15", "Minimal Rings", "Image"], ["w16", "Drifting Blobs", "Animated"], ["w17", "Aurora Flow", "Animated"], ["w18", "Twinkling Stars", "Animated"], ["w19", "Rising Bubbles", "Animated"], ["w20", "Moving Ocean", "Animated"], ["w21", "Sunset Waves", "Animated"], ["w22", "Spinning Rings", "Animated"], ["w23", "Color Cycle", "Animated"], ["w24", "Heavy Rain", "Animated"], ["w25", "Sonar Pulse", "Animated"], ["w26", "Orbits", "Animated"], ["w27", "Falling Snow", "Animated"], ["w28", "Fireflies", "Animated"], ["w29", "Spiral Galaxy", "Animated"], ["w30", "Lava Lamp", "Animated"], ["w31", "Neon Grid", "Animated"]],
 styler(s){const st=s.st||{},c=(h,o)=>{const n=parseInt((h||'#141628').slice(1),16)||0;return'rgba('+(n>>16)+','+(n>>8&255)+','+(n&255)+','+o/100+')'};let css='';
  const g=(t,sel,db)=>{const v=st[t];if(!v)return'';const bg=v.bg||db;
   return sel+'{'+(v.o!=null?'background:'+c(bg,v.o)+'!important;':v.bg?'background:'+v.bg+'!important;':'')+(v.b!=null?'backdrop-filter:blur('+v.b+'px)!important;':'')+(v.r!=null?'border-radius:'+v.r+'px!important;':'')+(v.glow?'box-shadow:0 0 18px var(--ac,#4c6ef5)!important;border-color:var(--ac,#4c6ef5)!important;':'')+'}\n'+(v.css||'')+'\n'};
  if(document.getElementById('desk'))css+=g('tb','#bar','#141628')+g('sm','#menu','#181a2e');
  const x=st.ex;if(x&&document.body&&document.body.dataset.app=='explorer')css+='body[data-app=explorer]{'+(x.bg?'background:'+x.bg+'!important;':'')+'}\n.it,.th,#cm{'+(x.r!=null?'border-radius:'+x.r+'px!important;':'')+'}\n'+(x.glow?'.it.sel{box-shadow:0 0 12px var(--ac,#4c6ef5)}\n':'')+(x.css||'');
  return css},
 esc:s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';'),
 perms(){let g={};try{g=JSON.parse(localStorage.getItem('win12perm')||'{}')}catch{}return{network:'ask',system:'ask',...g}},
 setPerm(l,v){const g=W.perms();g[l]=v;try{localStorage.setItem('win12perm',JSON.stringify(g))}catch{}},
 perm(level,why){const m=W.perms()[level];if(m=='allow')return Promise.resolve(true);if(m=='deny')return Promise.resolve(false);
  return new Promise(res=>{const d=document.createElement('div'),b='padding:7px 18px;border:0;border-radius:16px;color:#fff;font:inherit;cursor:pointer;background:';
   d.style.cssText='position:fixed;inset:0;z-index:2147483000;background:#000b;display:flex;align-items:center;justify-content:center;font:14px "Segoe UI",system-ui,sans-serif';
   d.innerHTML='<div style="width:min(360px,92vw);padding:18px;border-radius:14px;background:#23263b;color:#fff;border:1px solid #ffffff33"><b>'+(level=='system'?'System-level access':'Network-level access')+'</b><p style="color:#c5c9e0">'+why+'</p><label style="font-size:12px;color:#9aa0c0"><input type="checkbox"> Always allow '+level+' access</label><div style="margin-top:14px;display:flex;gap:8px;justify-content:flex-end"><button style="'+b+'#2f3350">Deny</button><button style="'+b+'#4c6ef5">Allow</button></div></div>';
   const q=d.querySelectorAll('button'),c=d.querySelector('input'),end=v=>{if(v&&c.checked)W.setPerm(level,'allow');d.remove();res(v)};
   q[0].onclick=()=>end(false);q[1].onclick=()=>end(true);document.body.append(d)})},
 resetPC(){['win12vfs','win12installed','win12user','win12fs','win12trash'].forEach(k=>{try{localStorage.removeItem(k)}catch{}})},
 ext:{txt:['Text document','#4c6ef5'],lnk:['Shortcut','#9b6bff'],exe:['Application','#12b886'],apk:['Android package','#34a853'],pdf:['PDF document','#e5484d'],dll:['Library','#8b93c8'],html:['Web page','#f59f00'],zip:['Compressed folder','#e0a21b'],png:['PNG image','#4cc9f0'],ico:['Icon','#fbbc05'],log:['Log file','#6b7099'],tmp:['Temporary file','#6b7099'],js:['JavaScript file','#d4b800'],md:['Markdown file','#9aa0c0']},
 extIcon(e){e=(e||'').toLowerCase().replace(/[^a-z0-9]/g,'');const c=(W.ext[e]||['','#6b7099'])[1];
  return'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M14 4h26l12 12v44H14z" fill="#e8ecf8"/><path d="M40 4v12h12z" fill="#aab3d6"/><rect x="8" y="34" width="40" height="18" rx="4" fill="'+c+'"/><text x="28" y="47" font-family="Arial" font-size="11" font-weight="700" text-anchor="middle" fill="#fff">'+e.slice(0,4).toUpperCase()+'</text></svg>')},
 vfs:{
  all(){try{return JSON.parse(localStorage.getItem('win12vfs')||'{}')}catch{return{}}},
  wr(o){try{localStorage.setItem('win12vfs',JSON.stringify(o));return true}catch{return false}},
  get(p){return W.vfs.all()[p]},
  put(p,c,h){const o=W.vfs.all(),s=c==null?'':String(c),old=o[p]&&o[p].c?o[p].c.length*2:0;if(W.vfs.size()-old+s.length*2>10485760)return false;o[p]={c:s,h:h?1:0,m:Date.now()};return W.vfs.wr(o)},
  mkdir(p,h){const o=W.vfs.all();if(!o[p])o[p]={d:1,h:h?1:0,m:Date.now()};return W.vfs.wr(o)},
  rm(p){const o=W.vfs.all();Object.keys(o).forEach(k=>{if(k==p||k.startsWith(p+'/'))delete o[k]});W.vfs.wr(o)},
  list(d){const o=W.vfs.all(),pre=d?d+'/':'',r={};Object.keys(o).forEach(k=>{if(k.startsWith(pre)){const n=k.slice(pre.length).split('/')[0];if(n&&!r[n])r[n]=o[pre+n]||{d:1,m:0}}});return Object.entries(r)},
  size(d){const o=W.vfs.all();return Object.keys(o).filter(k=>!d||k==d||k.startsWith(d+'/')).reduce((a,k)=>a+(o[k].c?o[k].c.length*2:0),0)}
 },
 fs:{
  dir:'C:\\phonelink\\WINDOWS 12 HTML\\admin\\Documents\\',D:'admin/Documents',T:'admin/$Recycle.Bin',
  rd(k,d){try{return JSON.parse(localStorage.getItem(k)||d)}catch{return JSON.parse(d)}},
  wr(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch{return false}},
  mig(){const f=W.fs.rd('win12fs','null'),t=W.fs.rd('win12trash','null');
   if(f){Object.entries(f).forEach(([n,c])=>W.vfs.put(W.fs.D+'/'+n,c));localStorage.removeItem('win12fs')}
   if(t){Object.entries(t).forEach(([n,c])=>W.vfs.put(W.fs.T+'/'+n,c));localStorage.removeItem('win12trash')}},
  ls(d){W.fs.mig();const r={};W.vfs.list(d).forEach(([n,v])=>{if(!v.d)r[n]=v.c});return r},
  files(){return W.fs.ls(W.fs.D)},trash(){return W.fs.ls(W.fs.T)},
  cfg(){return{auto:'Off',max:'500',trash:'On',warn:'80',...W.fs.rd('win12disk','{}')}},
  setCfg(o){W.fs.wr('win12disk',{...W.fs.cfg(),...o})},
  save(n,t){return W.vfs.put(W.fs.D+'/'+n,t)},
  del(n){const q=W.fs.D+'/'+n,v=W.vfs.get(q);if(!v)return;if(W.fs.cfg().trash=='On')W.vfs.put(W.fs.T+'/'+n,v.c);W.vfs.rm(q)},
  restore(n){const v=W.vfs.get(W.fs.T+'/'+n);if(v){W.vfs.put(W.fs.D+'/'+n,v.c);W.vfs.rm(W.fs.T+'/'+n)}},
  empty(){W.vfs.rm(W.fs.T)},
  format(){W.vfs.rm(W.fs.D);W.vfs.rm(W.fs.T);W.vfs.mkdir(W.fs.D)}
 }
};
return W})();
