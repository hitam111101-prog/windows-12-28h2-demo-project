/* Windows 12 loading screen.  Usage: winLoading('Restarting', 2500, () => {...});  winLoadingHide() removes it. */
function winLoading(text, ms, done) {
  winLoadingHide();
  if (!document.getElementById('wl-css')) {
    const s = document.createElement('style'); s.id = 'wl-css';
    s.textContent = `#wl{position:fixed;inset:0;z-index:2147483647;background:#000;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:40px;font:16px "Segoe UI",system-ui,sans-serif}
#wl svg{width:84px;height:84px}
#wl .sp{position:relative;width:40px;height:40px}
#wl .sp i{position:absolute;inset:0;animation:wl 2s cubic-bezier(.4,.1,.6,.9) infinite}
#wl .sp i::after{content:"";position:absolute;top:0;left:50%;width:5px;height:5px;margin-left:-2.5px;border-radius:50%;background:#fff}
@keyframes wl{to{transform:rotate(360deg)}}
@media(prefers-reduced-motion:reduce){#wl .sp i{animation-duration:8s}}`;
    document.head.appendChild(s);
  }
  const d = document.createElement('div'); d.id = 'wl';
  d.innerHTML = '<svg viewBox="0 0 48 48"><defs><linearGradient id="wlg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6fd3ff"/><stop offset="1" stop-color="#3b6cff"/></linearGradient></defs><g fill="url(#wlg)"><rect x="5" y="5" width="18" height="18" rx="2"/><rect x="25" y="5" width="18" height="18" rx="2"/><rect x="5" y="25" width="18" height="18" rx="2"/><rect x="25" y="25" width="18" height="18" rx="2"/></g></svg>'
    + '<div class="sp">' + [0, 1, 2, 3, 4].map(n => '<i style="animation-delay:' + n * 0.18 + 's"></i>').join('') + '</div><div>' + text + '</div>';
  document.body.appendChild(d);
  if (done) setTimeout(done, ms);
}
function winLoadingHide() { const d = document.getElementById('wl'); if (d) d.remove(); }
