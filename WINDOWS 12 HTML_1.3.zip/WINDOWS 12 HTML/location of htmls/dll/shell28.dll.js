/* shell29.dll.js - Windows 12 29h2 desktop shell: Start menu folders with transparent glass tiles */
(()=>{
const W=Win12,$=s=>document.querySelector(s),S=()=>W.settings(),is29=()=>W.is29(),esc=W.esc;
const DEF=[{n:'System',a:['Settings','Task Manager','Command Prompt','PowerShell','Disk Manager','App Manager','Storage Cleaner','Extensions']},{n:'Productivity',a:['File Explorer','Text Editor','Notepad','Calculator','AI Assistant']},{n:'Internet',a:['Google Chrome','YouTube','Microsoft Store','Screen Share']},{n:'Fun',a:['Games']}];
const folders=()=>S().folders||DEF,open=new Set();
const st=document.createElement('style');
st.textContent='.fld{display:inline-block;vertical-align:top;border-radius:18px;background:rgba(255,255,255,var(--fo,.1));backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.22);margin:2px}.fld .fh{display:flex;flex-direction:column;align-items:center;gap:4px;width:88px;padding:8px 4px;background:none;border:0;color:#fff;font:inherit;font-size:12px;cursor:pointer}.fld .mini{display:grid;grid-template-columns:repeat(2,26px);gap:3px;padding:6px;border-radius:12px;background:rgba(255,255,255,.08)}.fld .mini img{width:26px;height:26px}.fld .fb{display:none;padding:6px}.fld.open{display:block;width:100%}.fld.open .fb{display:flex;flex-wrap:wrap;gap:6px}.fld.open .fh{flex-direction:row;width:100%;justify-content:flex-start;padding:8px 12px;gap:10px;font-size:14px}.fld.open .mini{display:none}#menu.w11 #apps .fld.open{grid-column:1/-1}';
document.head.append(st);
function renderFolders(){const apps=$('#apps');if(!is29())return;apps.innerHTML='';const used=new Set();
 folders().forEach(f=>{const list=f.a.map(n=>vis().find(a=>a.n==n)).filter(Boolean);if(!list.length)return;list.forEach(a=>used.add(a.n));
  const d=document.createElement('div');d.className='fld'+(open.has(f.n)?' open':'');d.dataset.f=f.n;
  d.innerHTML='<button class="fh" title="'+esc(f.n)+'"><span class="mini">'+list.slice(0,4).map(a=>'<img src="'+a.i+'" alt="">').join('')+'</span><span class="fn">'+esc(f.n)+'</span></button><div class="fb"></div>';
  const fb=d.querySelector('.fb');list.forEach(a=>fb.append(mk(a)));apps.append(d)});
 vis().filter(a=>!used.has(a.n)).forEach(a=>apps.append(mk(a)))}
$('#apps').addEventListener('click',e=>{const h=e.target.closest('.fh');if(!h)return;const d=h.closest('.fld'),n=d.dataset.f;d.classList.toggle('open');d.classList.contains('open')?open.add(n):open.delete(n)});
const editF=fn=>{const f=JSON.parse(JSON.stringify(folders()));fn(f);W.set({folders:f});renderFolders()};
const mv=(n,to,create)=>editF(f=>{f.forEach(x=>x.a=x.a.filter(y=>y!=n));if(to){let x=f.find(y=>y.n==to);if(!x&&create){x={n:to,a:[]};f.push(x)}if(x)x.a.push(n)}});
document.addEventListener('contextmenu',e=>{if(!is29())return;const t=e.target;if(!t.closest('#menu'))return;const fld=t.closest('.fld'),ib=t.closest('.ic[data-n]');if(!fld&&!ib)return;
 e.preventDefault();e.stopImmediatePropagation();const X=e.clientX,Y=e.clientY,F=folders();
 if(ib&&!t.closest('.fh')){const n=ib.dataset.n,a=app(n);ctx(X,Y,[['Open',()=>openApp(a)],['Pin to taskbar (4 at most)',()=>pin(n)],...F.map(f=>['Move to folder: '+f.n,()=>mv(n,f.n)]),['New folder with this app...',()=>{const nm=prompt('Folder name');if(nm)mv(n,nm,true)}],['Remove from folder',()=>mv(n,null)]]);return}
 const fn=fld.dataset.f;ctx(X,Y,[['Rename folder...',()=>{const nm=prompt('New name',fn);if(nm)editF(f=>{const x=f.find(y=>y.n==fn);if(x)x.n=nm})}],['Delete folder (apps stay in Start)',()=>editF(f=>{const i=f.findIndex(y=>y.n==fn);if(i>=0)f.splice(i,1)})]])},true);
new MutationObserver(()=>{if($('#menu').classList.contains('on'))renderFolders()}).observe($('#menu'),{attributes:true,attributeFilter:['class']});
const oa=W.apply;W.apply=function(s){oa.call(W,s);s=s||S();document.documentElement.style.setProperty('--fo',(s.foOpacity==null?10:s.foOpacity)/100)};
W.f29={render:renderFolders,mv,folders};
W.apply();
})();
