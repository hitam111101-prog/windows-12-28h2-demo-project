/* utilman.dll.js - Utility Manager: Ease of Access and display quick settings for the taskbar tray */
const Utilman=(()=>{
const KEY='win12access',D={hc:false,large:false,rm:false,night:false,mag:'100',bright:100};
const U={
 cfg(){try{return{...D,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return{...D}}},
 set(o){try{localStorage.setItem(KEY,JSON.stringify({...U.cfg(),...o}))}catch{}U.apply()},
 apply(){const c=U.cfg(),h=document.documentElement;
  h.classList.toggle('ua-hc',c.hc);h.classList.toggle('ua-large',c.large);h.classList.toggle('ua-rm',c.rm);
  h.style.filter=(c.bright!=100?'brightness('+c.bright/100+') ':'')+(c.night?'sepia(.4) saturate(.9)':'');
  if(document.body)document.body.style.zoom=c.mag/100},
 panel(el){const c=U.cfg(),sw=(k,l)=>'<label class="qr"><span>'+l+'</span><input type="checkbox" data-k="'+k+'"'+(c[k]?' checked':'')+'></label>';
  el.innerHTML='<h4>Quick settings</h4><label class="qr"><span>Brightness</span><input type="range" min="40" max="100" value="'+c.bright+'" data-k="bright"></label>'+sw('night','Night light')
   +'<h4>Ease of Access</h4>'+sw('hc','High contrast')+sw('large','Large text')+sw('rm','Reduce motion')
   +'<label class="qr"><span>Magnifier</span><select data-k="mag">'+['100','125','150','200'].map(v=>'<option value="'+v+'"'+(c.mag==v?' selected':'')+'>'+v+'%</option>').join('')+'</select></label>';
  el.oninput=e=>{const t=e.target,k=t.dataset.k;if(k)U.set({[k]:t.type=='checkbox'?t.checked:t.type=='range'?+t.value:t.value})}}
};
return U})();
