/* install.dll.js - Windows 12 Setup library: creates the user profile on the virtual disk */
const Install={
 done(){try{return localStorage.getItem('win12installed')=='1'}catch{return true}},
 profile(user){const v=Win12.vfs;
  ['admin','admin/Documents','admin/Downloads','admin/Desktop','admin/Pictures'].forEach(p=>v.mkdir(p));
  ['admin/AppData','admin/AppData/Local','admin/AppData/Local/Temp','admin/AppData/Roaming'].forEach(p=>v.mkdir(p,1));
  v.put('admin/desktop.ini','[.ShellClassInfo]\nLocalizedResourceName=admin\n',1);
  v.put('admin/NTUSER.DAT','Windows 12 registry hive (demo)\n',1);
  v.put('admin/AppData/Roaming/profile.json',JSON.stringify({user,created:new Date().toISOString()}),1);
  v.put('admin/AppData/Local/Temp/setup.tmp','temporary setup data\n'.repeat(300));
  v.put('admin/AppData/Local/Temp/install.log','Windows 12 setup log\n'.repeat(80));
  v.put('admin/Documents/Welcome.txt','Welcome to Windows 12 Professional, '+user+'!\n\nThis file lives in C:\\W12_28H2\\WINDOWS 12 HTML\\admin\\Documents.\nRight-click inside File Explorer or on the desktop to create new files.\n')},
 finish(o){Install.profile(o.user);try{Win12.sysfiles();localStorage.setItem('win12installdate',new Date().toISOString());localStorage.setItem('win12ver','27h2');localStorage.removeItem('win12act');localStorage.setItem('win12installed','1');localStorage.setItem('win12user',JSON.stringify(o))}catch{}}
};
