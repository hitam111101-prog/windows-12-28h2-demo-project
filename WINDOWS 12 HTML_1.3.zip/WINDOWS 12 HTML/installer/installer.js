/* Windows 12 Setup wizard */
const $=s=>document.querySelector(s),W=Win12,esc=W.esc,S=['Language','License','Edition and disk','Installing','Account','Finish'];
let i=0,o={lang:'English (United States)',ok:false,user:'Admin'};
const LIC='<b>WINDOWS 12 SOFTWARE LICENSE TERMS (demo)</b><br><br>This is a hobby web desktop. It is provided as is, without any warranty. It does not change your real Windows. Files you save live in this browser, and real folders are only touched when you pick them yourself in Storage Cleaner. By continuing you agree to use it at your own risk.';
const pages=[
 ()=>'<label>Language<select id="l">'+['English (United States)','English (India)','Hindi','Marathi'].map(v=>'<option'+(o.lang==v?' selected':'')+'>'+v+'</option>').join('')+'</select></label><label>Keyboard<select><option>US</option><option>India (Devanagari)</option></select></label>',
 ()=>'<div class="lic">'+LIC+'</div><label class="chk"><input type="checkbox" id="ok"'+(o.ok?' checked':'')+'> I accept the license terms</label>',
 ()=>'<div class="card"><b>'+W.text('Edition > Name')+'</b><br><small>Version '+W.text('Edition > Version')+', build '+W.text('Edition > Build')+'</small></div><label>Install Windows on<select><option>C: (476 GB, primary partition)</option></select></label><p class="n">Setup copies its files from C:\\ESD. After install you can remove that folder with Storage Cleaner.</p>',
 install,
 ()=>'<label>User name<input id="u" maxlength="20" value="'+esc(o.user)+'"></label><p class="n">Your Documents, Downloads, Desktop and hidden AppData folders are created in C:\\W12_28H2\\WINDOWS 12 HTML\\admin.</p>',
 ()=>'<p>Windows 12 is installed. The PC will restart now.</p><div class="bar"><i style="width:100%"></i></div>'];
async function install(){$('#c').innerHTML='<div class="bar"><i id="pb"></i></div><pre id="lg"></pre>';$('#bk').disabled=true;
 if(!await W.perm('system','Windows Setup wants to create system files and folders on drive C:.')){$('#c').insertAdjacentHTML('afterbegin','<p class="err">Setup needs system-level access. Press Back, then Next, and choose Allow.</p>');$('#bk').disabled=false;return}
 const L=['Copying files from C:\\ESD ...','Expanding Windows files ...','Installing features ...','Installing drivers (Intel graphics, audio) ...','Creating user folders (Documents, Downloads, Desktop) ...','Creating the hidden AppData folder ...','Applying settings ...'];
 for(let k=0;k<L.length;k++){$('#lg').textContent+=L[k]+'\n';$('#pb').style.width=(k+1)/L.length*100+'%';await new Promise(r=>setTimeout(r,900))}
 go(4)}
function go(n){i=n;$('#t').textContent=S[i];$('#steps').innerHTML=S.map((x,k)=>'<li class="'+(k==i?'on':k<i?'done':'')+'">'+x+'</li>').join('');
 $('#bk').disabled=i==0||i>=3;$('#nx').disabled=i==3||i==5;$('#nx').textContent=i==2?'Install':i==4?'Finish':'Next';
 const r=pages[i]();if(typeof r=='string')$('#c').innerHTML=r;
 if(i==5){Install.finish(o);setTimeout(()=>winLoading('Restarting',2500,()=>location.href='../bios/bios.html'),2500)}}
$('#nx').onclick=()=>{if(i==0)o.lang=$('#l').value;
 if(i==1){o.ok=$('#ok').checked;if(!o.ok){if(!$('.err'))$('#c').insertAdjacentHTML('beforeend','<p class="err">Accept the license terms to continue.</p>');return}}
 if(i==4)o.user=$('#u').value.trim()||'Admin';go(i+1)};
$('#bk').onclick=()=>go(i-1);
W.load().then(()=>go(0));
