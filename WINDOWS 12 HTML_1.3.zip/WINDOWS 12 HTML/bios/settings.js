/* BIOS settings, saved in this browser (localStorage) */
const BIOS_DEFAULTS={virt:'Enabled',ht:'Enabled',usb:'Enabled',sata:'AHCI',sb:'Enabled',tpm:'Enabled',fast:'Disabled',delay:'5',ls:'3'};
function biosGet(){try{return{...BIOS_DEFAULTS,...JSON.parse(localStorage.getItem('win12bios')||'{}')}}catch{return{...BIOS_DEFAULTS}}}
function biosSave(o){try{localStorage.setItem('win12bios',JSON.stringify(o))}catch{}}
