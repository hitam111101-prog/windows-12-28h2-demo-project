Windows setup files (ESD). Safe to delete after Windows is installed.
