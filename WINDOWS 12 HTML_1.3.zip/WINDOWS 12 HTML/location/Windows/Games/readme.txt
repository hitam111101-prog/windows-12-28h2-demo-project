Games folder. Safe to delete if you need space.
